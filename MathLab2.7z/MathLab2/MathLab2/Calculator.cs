﻿using System;
using System.Collections.Generic;

namespace Calculator
{
    class Calculator
    {
        public double ParseFormula(string input)
        { //Gå igenom input från vänster till höger och interpretera ciffror och operatorer
            
            double result = 0;
            string temp = "";
            bool isText = false;
            List<double> argument = new List<double>();

            for (int i = 0; i < input.Length; i++)
            {
                if (IsNumericChar(input[i]))
                {
                    if (isText) //previous characters was an operator
                    {

                    }
                }
            }

            return result;
        }

        private bool IsNumericChar(char c)
        {
            char[] numeriska = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ',', '.' };
            foreach (char a in numeriska)
            {
                if (a == c)
                { return true; }
            }
            return false;
        }

        public double Addition(double a, double b)
        {
            double[] factors = { a, b };
            return CalculationFactory.Instance.CreateCalculation("+").Calc(factors);
        }

        public double Division(double a, double b)
        {
            double[] factors = { a, b };
            return CalculationFactory.Instance.CreateCalculation("/").Calc(factors);
        }

        public double Multiplication(double a, double b)
        {
            double[] factors = { a, b };
            return CalculationFactory.Instance.CreateCalculation("*").Calc(factors);
        }

        public double Subtraction(double a, double b)
        {
            double[] factors = { a, b };
            return CalculationFactory.Instance.CreateCalculation("-").Calc(factors);
        }

        public double Square(double a)
        {
            double[] factors = { a };
            return CalculationFactory.Instance.CreateCalculation("sq").Calc(factors);
        }

        public double SquareRoot(double a)
        {
            double[] factors = { a };
            return CalculationFactory.Instance.CreateCalculation("sqr").Calc(factors);
        }
    }
}
