﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Calculator
{
    abstract class AbstractCalculation
    {
        private List<AbstractCalculation> calcFactors = new List<AbstractCalculation>();
        private List<double> numFactors = new List<double>();
        public int NumArguments
        {
            get { return GetNumArguments(); }
        }
        public abstract double Calc(double[] factors);

        protected virtual int GetNumArguments()
        {
            return 2;
        }
        public void AddFactor(double number)
        {
            numFactors.Add(number);
        }
        public void AddFactor(AbstractCalculation calc)
        {
            calcFactors.Add(calc);
        }
        public double Result()
        {
            double[] factors = new double[numFactors.Count + calcFactors.Count];
            int i = 0;
            foreach (AbstractCalculation calc in calcFactors)
            {
                factors[i] = calc.Result();
                i++;
            }
            foreach (double x in numFactors)
            {
                factors[i] = x;
                i++;
            }
            return Calc(factors);
        }
    }

    delegate AbstractCalculation CalculationConstructor();

    class CalculationFactory
    {
        Dictionary<string, CalculationConstructor> concreteCalculationDict = new Dictionary<string, CalculationConstructor>();
        private static CalculationFactory instance;

        public static CalculationFactory Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CalculationFactory();
                    RegisterCalculations();
                }
                return instance;
            }
        }

        public void RegisterConstructor(string key, CalculationConstructor constructor)
        {
            concreteCalculationDict.Add(key, constructor);
        }

        public List<string> GetCalculationNames()
        {
            List<string> result = new List<string>();
            result.AddRange(concreteCalculationDict.Keys);
            return result;
        }

        public AbstractCalculation CreateCalculation(string key)
        {
            if (concreteCalculationDict.ContainsKey(key))
            {
                return concreteCalculationDict[key]();
            }
            else
            {
                return null;
                //throw new ECalcException(String.Format("Unknown operator ({0})", key));
            }
        }

        private static void RegisterCalculations()
        {
            foreach (Type type in Assembly.GetEntryAssembly().GetTypes())
            {
                if (typeof(AbstractCalculation).IsAssignableFrom(type))
                {
                    RuntimeHelpers.RunClassConstructor(type.TypeHandle);
                }
            }
        }
    }
}
