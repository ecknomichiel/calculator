﻿using System;
using Calculator;

namespace MathLab2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Console.WriteLine("Skriv en calculation som du vill utföras, eller en tom rad för att avsluta.");
            string input = "not empty";
            Calculator.Calculator calc = new Calculator.Calculator();
            while (input != "")
            {
                input = Console.ReadLine();
                try
                {
                    Console.WriteLine("={0}", calc.ParseFormula(input));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            
        }
    }
}