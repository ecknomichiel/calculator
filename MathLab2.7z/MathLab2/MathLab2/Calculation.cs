﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator
{
    // Moved AbstractCalculation to CalculationFactory

    class Addition: AbstractCalculation
    {
        public override double Calc(double[] factors)
        {
            if (factors.Length < 2)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Minimum is 2", base.ToString(), factors.Length));
            }
            double result = factors[0];
            for(int i = 1; i < factors.Length; i++)
            {
                result += factors[i];
            }
            return result;
        }

        static Addition()
        {
            CalculationFactory.Instance.RegisterConstructor("+", Create);
        }

        public static Addition Create()
        {
            return new Addition();
        }
    }
    class Subtraction : AbstractCalculation
    {
        public override double Calc(double[] factors)
        {
            if (factors.Length < 2)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Minimum is 2", base.ToString(), factors.Length));
            }
            double result = factors[0];
            for (int i = 1; i < factors.Length; i++)
            {
                result -= factors[i];
            }
            return result;
        }

        static Subtraction()
        {
            CalculationFactory.Instance.RegisterConstructor("-", Create);
        }

        public static Subtraction Create()
        {
            return new Subtraction();
        }
    }

    class Multiplication : AbstractCalculation
    {
        public override double Calc(double[] factors)
        {
            if (factors.Length < 2)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Minimum is 2", base.ToString(), factors.Length));
            }
            double result = factors[0];
            for (int i = 1; i < factors.Length; i++)
            {
                result *= factors[i];
            }
            return result;
        }

        static Multiplication()
        {
            CalculationFactory.Instance.RegisterConstructor("*", Create);
        }

        public static Multiplication Create()
        {
            return new Multiplication();
        }
    }

    class Division : AbstractCalculation
    {
        public override double Calc(double[] factors)
        {
            if (factors.Length < 2)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Minimum is 2", base.ToString(), factors.Length));
            }
            double result = factors[0];
            for (int i = 1; i < factors.Length; i++)
            {
                result /= factors[i];
            }
            return result;
        }

        static Division()
        {
            CalculationFactory.Instance.RegisterConstructor("/", Create);
        }

        public static Division Create()
        {
            return new Division();
        }
    }

    class Square : AbstractCalculation
    {
        public override double Calc(double[] factors)
        {
            if (factors.Length != 1)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Square (x²) takes one argument.", base.ToString(), factors.Length));
            }

            return Math.Pow(factors[0], 2);
        }

        protected override int GetNumArguments()
        {
            return 1; 
        }

        static Square()
        {
            CalculationFactory.Instance.RegisterConstructor("sqr", Create);
        }

        public static Square Create()
        {
            return new Square();
        }
    }

    class SquareRoot : AbstractCalculation
    {
        protected override int GetNumArguments()
        {
            return 1;
        }

        public override double Calc(double[] factors)
        {
            if (factors.Length != 1)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Square root takes one argument.", base.ToString(), factors.Length));
            }

            return Math.Sqrt(factors[0]);
        }

        static SquareRoot()
        {
            CalculationFactory.Instance.RegisterConstructor("sqrt", Create);
        }

        public static SquareRoot Create()
        {
            return new SquareRoot();
        }
    }

    class Fibonacci : AbstractCalculation
    {
        protected override int GetNumArguments()
        {
            return 1;
        }

        public override double Calc(double[] factors)
        {
            if (factors.Length != 1)
            {
                throw new ECalcException(String.Format("{0}: Invalid number of arguments ({1}). Fibonacci takes one argument.", base.ToString(), factors.Length));
            }
            int n = (int)factors[0];
            if (n < 0)
            {
                throw new ECalcException(String.Format("{0}: Number out of range ({1}). Fibonaccy takes only positive integers as argument.", base.ToString(), n));
            }
            if (n < 2)
            {
                return n;
            }
            double prevResult = 0;
            double tempResult = 0;
            double result = 1;
            for (int i = 1; i < n; i++)
            {
                tempResult = result;
                result = prevResult + result;
                prevResult = tempResult;
            }
            
            return result;
        }

        static Fibonacci()
        {
            CalculationFactory.Instance.RegisterConstructor("fib(", Create);
        }

        public static Fibonacci Create()
        {
            return new Fibonacci();
        }
    }

    class ECalcException: Exception
    {
        public ECalcException(string message): base(message)
        {

        }
    }
}
